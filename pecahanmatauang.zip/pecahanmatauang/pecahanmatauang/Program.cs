﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace pecahanmatauang
{
    class Program
    {
        static void Main(string[] args)
        {
            double jmlUang, s100rb, s50rb, s20rb, s10rb, s5rb, s1rb;
            int p100rb, p50rb, p20rb, p10rb, p5rb, p1rb;
            Console.Write("Msukkan Nilai Uang: ");
            jmlUang = Convert.ToDouble(Console.ReadLine());

            p100rb = (int)(jmlUang / 100000);
            s100rb = jmlUang - (p100rb * 100000);

            p50rb = (int)(s100rb / 50000);
            s50rb = s100rb - (p50rb * 50000);

            p20rb = (int)(s50rb / 20000);
            s20rb = s50rb - (p20rb * 20000);

            p10rb = (int)(s20rb / 10000);
            s10rb = s20rb - (p10rb * 10000);

            p5rb = (int)(s10rb / 5000);
            s5rb = s10rb - (p5rb * 5000);

            p1rb = (int)(s5rb / 1000);
            s1rb = s5rb - (p1rb * 1000);

            Console.WriteLine("Pecahan Yang Dihasilkan=");
            Console.WriteLine("100000= " + p100rb);
            Console.WriteLine("50000= " + p50rb);
            Console.WriteLine("20000= " + p20rb);
            Console.WriteLine("10000= " + p10rb);
            Console.WriteLine("5000= " + p5rb);
            Console.WriteLine("1000= " + p1rb);

            Console.ReadLine();
        }
    }
}
