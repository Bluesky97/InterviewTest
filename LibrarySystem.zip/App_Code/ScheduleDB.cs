﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data.SqlClient;
using System.Linq;
using System.Web;

/// <summary>
/// Summary description for ScheduleDB
/// </summary>
public class ScheduleDB
{
    public static string conStr = ConfigurationManager.ConnectionStrings["myConnectionString"].ConnectionString;

    public static List<Schedule> getAllSchedule()
    {
        SqlConnection con = new SqlConnection(conStr);
        try
        {
            SqlCommand command = new SqlCommand();
            command.Connection = con;
            command.CommandText = "Select LibraryUser.fullName as 'Full Name',Book.bookName as 'Book Name',takenDate,broughtDate from LibraryUser join Schedule on LibraryUser.userId = Schedule.userId join Book on Book.bookId = Schedule.bookId";
            con.Open();
            SqlDataReader reader = command.ExecuteReader();
            List<Schedule> Schedules = null;
            if (reader.HasRows)
                Schedules = new List<Schedule>();
            while (reader.Read())
            {
                Schedules.Add(
                    new Schedule()
                    {
                        ScheduleId = Convert.ToInt32(reader["scheduleId"].ToString()),
                        UserId = LibraryUserDB.getLibraryUserByID(reader["userId"].ToString()),
                        BookId = BookDB.getBookByID(reader["bookId"].ToString()),
                        TakenDate = Convert.ToDateTime(reader["takenDate"]),
                        BroughtDate = Convert.ToDateTime(reader["broughtDate"]),
                    });
            }
            reader.Close();
            return Schedules;
        }
        finally
        {
            con.Close();
        }
    }
}