﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

/// <summary>
/// Summary description for Schedule
/// </summary>
public class Schedule
{
    public int ScheduleId { get; set; }
    public LibraryUser UserId { get; set; }
    public Book BookId { get; set; }
    public DateTime TakenDate { get; set; }
    public DateTime BroughtDate { get; set; }
    public override string ToString()
    {
        return ScheduleId + " " + UserId + " " + BookId + " " + TakenDate + " " + BroughtDate;
    }
}