﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data.SqlClient;
using System.Linq;
using System.Web;

/// <summary>
/// Summary description for LibraryUserDB
/// </summary>
public class LibraryUserDB
{
    public static string conStr = ConfigurationManager.ConnectionStrings["myConnectionString"].ConnectionString;

    public static List<LibraryUser> getAllUsers()
    {
        SqlConnection con = new SqlConnection(conStr);
        try
        {
            SqlCommand command = new SqlCommand();
            command.Connection = con;
            command.CommandText = "Select * from LibraryUser";
            con.Open();
            SqlDataReader reader = command.ExecuteReader();
            List<LibraryUser> LibraryUsers = null;
            if (reader.HasRows)
                LibraryUsers = new List<LibraryUser>();
            while (reader.Read())
            {
                LibraryUsers.Add(
                    new LibraryUser()
                    {
                        UserId = Convert.ToInt32(reader["userId"].ToString()),
                        Username = reader["username"].ToString(),
                        Password = reader["password"].ToString(),
                        FullName = reader["fullName"].ToString(),
                        Gender = reader["gender"].ToString(),
                        Birthdate = Convert.ToDateTime(reader["birthdate"].ToString())
                    });
            }
            reader.Close();
            return LibraryUsers;
        }
        finally
        {
            con.Close();
        }
    }
    public static LibraryUser getLibraryUserByUsername(string username, string password)
    {
        SqlConnection con = new SqlConnection(conStr);
        try
        {
            SqlCommand command = new SqlCommand();
            command.Connection = con;
            command.CommandText = "Select * from LibraryUser where username=@username and password=@password";
            command.Parameters.AddWithValue("@username", username);
            command.Parameters.AddWithValue("@password", password);
            con.Open();
            SqlDataReader reader = command.ExecuteReader();
            LibraryUser c = null;
            if (reader.HasRows)
            {
                reader.Read();
                c = new LibraryUser()
                {
                    UserId = Convert.ToInt32(reader["userId"].ToString()),
                    Username = reader["username"].ToString(),
                    Password = reader["password"].ToString(),
                    FullName = reader["fullName"].ToString(),
                    Gender = reader["gender"].ToString(),
                    Birthdate = Convert.ToDateTime(reader["birthdate"].ToString())
                };

            }
            reader.Close();
            return c;
        }
        finally
        {
            con.Close();
        }
    }
    public static LibraryUser getLibraryUserByID(string id)
    {
        SqlConnection con = new SqlConnection(conStr);
        try
        {
            SqlCommand command = new SqlCommand();
            command.Connection = con;
            command.CommandText = "Select * from LibraryUser where LibraryUser=@id";
            command.Parameters.AddWithValue("@userId", id);
            con.Open();
            SqlDataReader reader = command.ExecuteReader();
            LibraryUser a = null;
            if (reader.HasRows)
            {
                reader.Read();
                a = new LibraryUser()
                {
                    UserId = Convert.ToInt32(reader["userId"].ToString()),
                    Username = reader["username"].ToString(),
                    Password = reader["password"].ToString(),
                    FullName = reader["fullName"].ToString(),
                    Gender = reader["gender"].ToString(),
                    Birthdate = Convert.ToDateTime(reader["birthdate"].ToString())
                };

            }
            reader.Close();
            return a;
        }
        finally
        {
            con.Close();
        }
    }
}