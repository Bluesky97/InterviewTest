﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data.SqlClient;
using System.Linq;
using System.Web;

/// <summary>
/// Summary description for BookDB
/// </summary>
public class BookDB
{
    public static string conStr = ConfigurationManager.ConnectionStrings["myConnectionString"].ConnectionString;

    public static List<Book> getAllBook()
    {
        SqlConnection con = new SqlConnection(conStr);
        try
        {
            SqlCommand command = new SqlCommand();
            command.Connection = con;
            command.CommandText = "Select * from Book";
            con.Open();
            SqlDataReader reader = command.ExecuteReader();
            List<Book> Books = null;
            if (reader.HasRows)
                Books = new List<Book>();
            while (reader.Read())
            {
                Books.Add(
                    new Book()
                    {
                        BookId = Convert.ToInt32(reader["bookId"].ToString()),
                        BookName = reader["bookName"].ToString(),
                    });
            }
            reader.Close();
            return Books;
        }
        finally
        {
            con.Close();
        }
    }
    public static Book getBookByID(string id)
    {
        SqlConnection con = new SqlConnection(conStr);
        try
        {
            SqlCommand command = new SqlCommand();
            command.Connection = con;
            command.CommandText = "Select * from Book where Book=@id";
            command.Parameters.AddWithValue("@bookId", id);
            con.Open();
            SqlDataReader reader = command.ExecuteReader();
            Book a = null;
            if (reader.HasRows)
            {
                reader.Read();
                a = new Book()
                {
                    BookId = Convert.ToInt32(reader["bookId"].ToString()),
                    BookName = reader["bookName"].ToString(),
                };

            }
            reader.Close();
            return a;
        }
        finally
        {
            con.Close();
        }
    }
}