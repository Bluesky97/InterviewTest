﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class Loginpage : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }

    protected void btnLogin_Click(object sender, EventArgs e)
    {
        //get user from database
        LibraryUser d = LibraryUserDB.getLibraryUserByUsername(tbxUsername.Text, tbxPassword.Text);
        if (d != null) //if admin is not null
        {
            if (d.Username == tbxUsername.Text) //check the usename from database, matched or not
            {
                if (d.Password == tbxPassword.Text) //check the password from database, matched or not
                {
                    //create a session for username
                    Session["username"] = d;
                    //redirect to AdminView page
                    Server.Transfer("Homepage.aspx");
                }
            }
        }
        else
        {
            lblOutput.Text = "sorry username cannot login!"; //to show error message
        }
    }
}