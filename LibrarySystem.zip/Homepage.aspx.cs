﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text.RegularExpressions;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class Homepage : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!this.IsPostBack)
        {
            this.BindGrid();
        }
        string constr = ConfigurationManager.ConnectionStrings["myConnectionString"].ConnectionString;

        SqlConnection con = new SqlConnection(constr);
        string com = "Select * from LibraryUser";
        SqlDataAdapter adpt = new SqlDataAdapter(com, con);
        DataTable dt = new DataTable();
        adpt.Fill(dt);
        ddlName.DataSource = dt;
        ddlName.DataBind();
        ddlName.DataTextField = "fullName";
        ddlName.DataValueField = "userId";
        ddlName.DataBind();

        SqlConnection con1 = new SqlConnection(constr);
        string com1 = "Select * from Book";
        SqlDataAdapter adpt1 = new SqlDataAdapter(com1, con1);
        DataTable dt1 = new DataTable();
        adpt1.Fill(dt1);
        ddlBook.DataSource = dt1;
        ddlBook.DataBind();
        ddlBook.DataTextField = "bookName";
        ddlBook.DataValueField = "bookId";
        ddlBook.DataBind();
    }
    private void BindGrid()
    {
        string constr = ConfigurationManager.ConnectionStrings["myConnectionString"].ConnectionString;
        using (SqlConnection con = new SqlConnection(constr))
        {
            using (SqlCommand cmd = new SqlCommand())
            {
                cmd.CommandText = "SELECT bookName FROM Book WHERE bookName LIKE '%' + @bookName + '%'";
                cmd.Connection = con;
                cmd.Parameters.AddWithValue("@bookName", tbxSearch.Text.Trim());
                DataTable dt = new DataTable();
                using (SqlDataAdapter sda = new SqlDataAdapter(cmd))
                {
                    sda.Fill(dt);
                    gvBook.DataSource = dt;
                    gvBook.DataBind();
                }
            }
        }
    }

    protected void btnSearch_Click(object sender, EventArgs e)
    {
        this.BindGrid();
    }

    protected void OnPageIndexChanging(object sender, GridViewPageEventArgs e)
    {
        gvBook.PageIndex = e.NewPageIndex;
        this.BindGrid();
    }

    protected void OnRowDataBound(object sender, GridViewRowEventArgs e)
    {
        if (e.Row.RowType == DataControlRowType.DataRow)
        {
            e.Row.Cells[0].Text = Regex.Replace(e.Row.Cells[0].Text, tbxSearch.Text.Trim(), delegate (Match match)
            {
                return string.Format("<span style = 'background-color:#D9EDF7'>{0}</span>", match.Value);
            }, RegexOptions.IgnoreCase);
        }
    }

    protected void btnSubmit_Click(object sender, EventArgs e)
    {
        string constr = ConfigurationManager.ConnectionStrings["myConnectionString"].ConnectionString;
        SqlConnection con = new SqlConnection(constr);
        SqlCommand cmd = new SqlCommand("insert into Schedule (scheduleId, userId, bookId, takenDate, broughtDate) values (@scheduleId, @userId, @bookId, @takenDate, @broughtDate)", con);
        cmd.Parameters.AddWithValue("scheduleId", tbxScheduleId.Text);
        cmd.Parameters.AddWithValue("userId", ddlName.SelectedValue);
        cmd.Parameters.AddWithValue("bookId", ddlBook.SelectedValue);
        cmd.Parameters.AddWithValue("takenDate", tbxTakenDate.Text);
        cmd.Parameters.AddWithValue("broughtDate", tbxBroughtDate.Text);
        con.Open();
        int i = cmd.ExecuteNonQuery();
        con.Close();
        if (i != 0)
        {
            lblOutput.Text = " Your data is been saved in the database";
            lblOutput.ForeColor = System.Drawing.Color.ForestGreen;

        }
        else
        {
            lblOutput.Text = "Something went wrong with selection";
            lblOutput.ForeColor = System.Drawing.Color.Red;

        }
    }
}