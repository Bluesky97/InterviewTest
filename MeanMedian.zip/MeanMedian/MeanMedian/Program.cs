﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MeanMedian
{
    class Program
    {
        static void Main(string[] args)
        {
            int[] num = { 12, 10, 5, 21, 27, 23, 1 };
            double mean = num.Average();

            int count = num.Count();
            int halfIndex = num.Count() / 2;
            var sortedNum = num.OrderBy(n => n);
            double median;
            if ((count % 2) == 0)
            {
                median = ((sortedNum.ElementAt(halfIndex) + sortedNum.ElementAt((halfIndex - 1))) / 2);
            }
            else
            {
                median = sortedNum.ElementAt(halfIndex);
            }

            Console.WriteLine("Mean: " + mean);
            Console.WriteLine("Median: " + median);
        }
    }
}
