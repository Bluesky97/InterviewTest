﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Text;
using System.Threading.Tasks;

namespace currencyconverter
{
    class Program
    {
        static void Main(string[] args)
        {
            for (int x = 0; x < 2; x++)
            {
                Console.WriteLine("Enter amount: ");
                int input = Convert.ToInt32(Console.ReadLine());
                Console.WriteLine("Enter currency: ");
                string currency = Console.ReadLine();
                using (var client = new WebClient()) //WebClient  
                {
                    client.Headers.Add("Content-Type:application/json"); //Content-Type  
                    client.Headers.Add("Accept:application/json");
                    string link = string.Format("https://api.frankfurter.app/latest?amount={0}&from={1}&to=USD", input, currency);
                    var result = client.DownloadString(link); //URI
                    Console.WriteLine(Environment.NewLine + result);
                }
            }

        }
    }
}
